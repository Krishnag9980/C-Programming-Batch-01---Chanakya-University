#include<stdio.h>
int main() {
    int marks;
    printf("Enter a Marks: ");
    scanf("%d",&marks);

    if(marks >= 90 && marks <= 100)
    {
        printf("Outstanding");
    }

    else if (marks >= 75 && marks <= 89)
    {
        printf("Distinction");
    } 

     else if (marks >= 65 && marks <= 74)
    {
        printf("First Class");
    } 

    else if (marks >= 45 && marks <= 64)
    {
        printf("Second Class");
    } 

     else if (marks >= 35 && marks <= 44)
    {
        printf("Just Pass ");
    } 

    else {
        printf("Tata Good Bye");
    }

    return 0;
}