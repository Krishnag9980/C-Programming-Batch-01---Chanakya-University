#include<stdio.h>
int main() {
    int value;
    printf("Enter the value: ");
    scanf("%d",&value);
    if (value>0)
    {
        printf("Number is positive");
   }
   return 0;
}        
            
    
    
